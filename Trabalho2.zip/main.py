import glm
from OpenGL.raw.GL._types import GLuint
import OpenGL.GL

import Camera

#define STB_IMAGE_IMPLEMENTATION

Width = 800
Height = 600

class Vertex():
	def __init__(self, pos: glm.vec3, nor: glm.vec3, col: glm.vec3, uv: glm.vec2):
		self.Position = pos
		self.Normal = nor
		self.Color = col
		self.UV = uv

class Triangle():
	def __init__(self, v0:GLuint, v1:GLuint, v2:GLuint):
		self.V0 = v0
		self.V1 = v1
		self.V2 = v2


class DirectionalLight():
	def __init__(self, dir:glm.vec3, intensity:GLfloat):
		self.Direction = dir
		self.Intensity = intensity


Camera = SimpleCamera()

def GenerateSphere(Resolution:GLuint, Vertices, Indices):
	Vertices.clear()
	Indices.clear()

	Pi = glm.pi<float>()
	TwoPi = glm.two_pi<float>()
	InvResolution = 1.0/float(Resolution - 1)


	for i in range(Resolution):
		UIndex = GLuint(i)
		U = UIndex * InvResolution
		Theta = glm.mix(0.0, TwoPi, float(U))

		for j in range(Resolution):
			VIndex = GLuint(j)
			V = VIndex * InvResolution;
			Phi = glm.mix(0.0, Pi, float(V))

			VertexPosition = glm.vec3
			(
				glm.cos(Theta) * glm.sin(Phi),
				glm.sin(Theta) * glm.sin(Phi),
				glm.cos(Phi)
			)

			VertexNormal = glm.normalize(VertexPosition)

			Vertices.push_back(Vertex{
				VertexPosition,
				VertexNormal,
				glm.vec3( 1.0, 1.0, 1.0 ),
				glm.vec2( 1.0 - U, 1.0 - V )
			})



	for i in range(Resolution-1):
		U = GLuint(i)
		for j in range(Resolution-1):
			V = GLuint(j)
			P0 = U + V * Resolution
			P1 = U + 1 + V * Resolution
			P2 = U + (V + 1) * Resolution
			P3 = U + 1 + (V + 1) * Resolution
			Indices.push_back(Triangle{ P3, P2, P0 })
			Indices.push_back(Triangle{ P1, P3, P0 })
		}
	}
}

def ReadFile(FilePath) -> str:

	std::string FileContents;
	if (std::ifstream FileStream{ FilePath, std::ios::in }):
		FileContents.assign((std.istreambuf_iterator<char>(FileStream)), std.istreambuf_iterator<char>())

	return FileContents


def CheckShader(ShaderId: GLuint):

	# Verificar se o shader foi compilado
	Result = GL_TRUE;
	glGetShaderiv(ShaderId, GL_COMPILE_STATUS, &Result)

	if (Result == GL_FALSE):

		# Erro ao compilar o shader, imprimir o log para saber o que est� errado
		InfoLogLength = GLint(0);
		glGetShaderiv(ShaderId, GL_INFO_LOG_LENGTH, &InfoLogLength)

		ShaderInfoLog(InfoLogLength, '\0');
		glGetShaderInfoLog(ShaderId, InfoLogLength, nullptr, &ShaderInfoLog[0])

		if (InfoLogLength > 0):
			print("Erro no Vertex Shader:")
			print(ShaderInfoLog)


def LoadShaders(VertexShaderFile, FragmentShaderFile) ->GLuint:

	# Criar os identificadores de cada um dos shaders
	VertShaderId = glCreateShader(GL_VERTEX_SHADER)
	FragShaderId = glCreateShader(GL_FRAGMENT_SHADER)

	VertexShaderSource = ReadFile(VertexShaderFile)
	FragmentShaderSource = ReadFile(FragmentShaderFile)

	assert(!VertexShaderSource.empty())
	assert(!FragmentShaderSource.empty())

	print(f"Compilando {VertexShaderFile}")
	VertexShaderSourcePtr = VertexShaderSource.c_str();
	glShaderSource(VertShaderId, 1, &VertexShaderSourcePtr, nullptr)
	glCompileShader(VertShaderId)
	CheckShader(VertShaderId)

	print(f"Compilando {FragmentShaderFile}")
	FragmentShaderSourcePtr = FragmentShaderSource.c_str()
	glShaderSource(FragShaderId, 1, &FragmentShaderSourcePtr, nullptr)
	glCompileShader(FragShaderId)
	CheckShader(FragShaderId)

	print("Linkando Programa")
	ProgramId = glCreateProgram()
	glAttachShader(ProgramId, VertShaderId)
	glAttachShader(ProgramId, FragShaderId)
	glLinkProgram(ProgramId)

	# Verificar o programa
	Result = GL_TRUE;
	glGetProgramiv(ProgramId, GL_LINK_STATUS, &Result)
	
	if (Result == GL_FALSE):
		InfoLogLength = GLint(0);
		glGetProgramiv(ProgramId, GL_INFO_LOG_LENGTH, &InfoLogLength)

		if (InfoLogLength > 0):

			ProgramInfoLog(InfoLogLength, '\0')
			glGetProgramInfoLog(ProgramId, InfoLogLength, nullptr, &ProgramInfoLog[0])

			print("Erro ao linkar o Programa")
			print(ProgramInfoLog)
			assert(False);



	glDetachShader(ProgramId, VertShaderId)
	glDetachShader(ProgramId, FragShaderId)

	glDeleteShader(VertShaderId)
	glDeleteShader(FragShaderId)

	return ProgramId;


def LoadTexture(TextureFile) -> GLuint:
	print(f"Carregando Textura {TextureFile}")

	TextureWidth = 0
	TextureHeight = 0
	NumberOfComponents = 0
	TextureData = stbi_load(TextureFile, &TextureWidth, &TextureHeight, &NumberOfComponents, 3)
	assert(TextureData);

	# Gerar o Identifador da Textura
	GLuint TextureId;
	glGenTextures(1, &TextureId)

	# Habilita a textura para ser modificada
	glBindTexture(GL_TEXTURE_2D, TextureId);

	# Copia a textura para a mem�ria da GPU
	Level = GLint(0)
	Border = GLint(0)
	glTexImage2D(GL_TEXTURE_2D, Level, GL_RGB, TextureWidth, TextureHeight, Border, GL_RGB, GL_UNSIGNED_BYTE, TextureData)
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR)
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
	glGenerateMipmap(GL_TEXTURE_2D)

	glBindTexture(GL_TEXTURE_2D, 0)

	stbi_image_free(TextureData)
	return TextureId


def MouseButtonCallback(Window: GLFWwindow*, Button: int, Action: int, Modifiers: int):

	# std::cout << "Button: " << Button << " Action: " << Action << " Modifiers: " << Modifiers << std::endl;

	if (Button == GLFW_MOUSE_BUTTON_LEFT):

		if (Action == GLFW_PRESS):

			glfwSetInputMode(Window, GLFW_CURSOR, GLFW_CURSOR_DISABLED)

			double X, Y;
			glfwGetCursorPos(Window, &X, &Y)
			
			Camera.PreviousCursor = glm.vec2(X,Y)
			Camera.bEnableMouseMovement = True

		elif (Action == GLFW_RELEASE):

			glfwSetInputMode(Window, GLFW_CURSOR, GLFW_CURSOR_NORMAL)
			Camera.bEnableMouseMovement = False




def MouseMotionCallback(Window: GLFWwindow* , X: float, Y: float):

	# std::cout << "X: " << X << " Y: " << Y << std::endl;
	Camera.MouseMove(X, Y);

def KeyCallback(Window: GLFWwindow* , Key: int, ScanCode: int, Action: int, Modifers: int):

	# std::cout << "Key: " << Key << " ScanCode: " << ScanCode << " Action: " << Action << " Modifiers: " << Modifers << std::endl;

	if (Action == GLFW_PRESS):
		if Key == GLFW_KEY_ESCAPE:
			glfwSetWindowShouldClose(Window, True);
			break;

		elif Key == GLFW_KEY_W:
			Camera.MoveForward(1.0)
			break;

		elif Key == GLFW_KEY_S:
			Camera.MoveForward(-1.0)
			break;

		elif Key == GLFW_KEY_A:
			Camera.MoveRight(-1.0)
			break;

		elif Key == GLFW_KEY_D:
			Camera.MoveRight(1.0)
			break;

		else:
			break;

	elif (Action == GLFW_RELEASE):
		if Key == GLFW_KEY_ESCAPE:
			glfwSetWindowShouldClose(Window, True)
			break

		elif Key == GLFW_KEY_W:
			Camera.MoveForward(0.0);
			break;

		elif Key == GLFW_KEY_S:
			Camera.MoveForward(0.0);
			break;

		elif Key == GLFW_KEY_A:
			Camera.MoveRight(0.0);
			break;

		elif Key == GLFW_KEY_D:
			Camera.MoveRight(0.0);
			break;

		else:
			break;


def main():
	if (not glfwInit()):
		print("Erro ao inicializar o GLFW")
		return 1;

	glfwWindowHint(GLFW_DEPTH_BITS, 32)

	GLFWwindow* Window = glfwCreateWindow(Width, Height, "Blue Marble", nullptr, nullptr)

	if (not Window):

		print("Erro ao criara a Janela")
		glfwTerminate()
		return 1

	
	glfwSetMouseButtonCallback(Window, MouseButtonCallback);
	glfwSetCursorPosCallback(Window, MouseMotionCallback);
	glfwSetKeyCallback(Window, KeyCallback);

	glfwMakeContextCurrent(Window);
	glfwSwapInterval(1);

	if (glewInit() != GLEW_OK):
		print("Erro ao inicializar o GLEW")
		glfwTerminate();
		return 1;


	GLMajorVersion = GLint(0)
	GLMinorVersion = GLint(0)
	glGetIntegerv(GL_MAJOR_VERSION, &GLMajorVersion)
	glGetIntegerv(GL_MINOR_VERSION, &GLMinorVersion)
	print(f"OpenGL Version   : {GLMajorVersion}.{GLMinorVersion}")
	print(f"OpenGL Vendor    : {glGetString(GL_VENDOR)}")
	print(f"OpenGL Renderer  : {glGetString(GL_RENDERER)}")
	print(f"OpenGL Veersion  : {glGetString(GL_VERSION)}")
	print(f"GLSL Version     : {glGetString(GL_SHADING_LANGUAGE_VERSION)}")


	# Habilita o Buffer de Profundidade
	glEnable(GL_DEPTH_TEST);

	# Escolhe a funcao de teste de profundidade.
	glDepthFunc(GL_ALWAYS);

	glDisable(GL_CULL_FACE);
	glEnable(GL_CULL_FACE);

	# Compilar o vertex e o fragment shader
	ProgramId = LoadShaders("shaders/triangle_vert.glsl", "shaders/triangle_frag.glsl");

	# Gera a Geometria da esfera e copia os dados para a GPU (mem�ria da placa de v�deo)
	std::vector<Vertex> SphereVertices;
	std::vector<Triangle> SphereIndices;
	GenerateSphere(100, SphereVertices, SphereIndices);
	GLuint SphereVertexBuffer, SphereElementBuffer;
	glGenBuffers(1, &SphereVertexBuffer);
	glGenBuffers(1, &SphereElementBuffer);
	glBindBuffer(GL_ARRAY_BUFFER, SphereVertexBuffer);
	glBufferData(GL_ARRAY_BUFFER, SphereVertices.size() * sizeof(Vertex), SphereVertices.data(), GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, SphereElementBuffer);	
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, SphereIndices.size() * sizeof(Triangle), SphereIndices.data(), GL_STATIC_DRAW);

	# Criar uma fonte de luz direcional
	Light = DirectionalLight();
	Light.Direction = glm.vec3(0.0, 0.0, -1.0)
	Light.Intensity = 1.0

	# Model View Projection
	ModelMatrix = glm.rotate(glm.identity<glm.mat4>(), glm.radians(90.0), glm.vec3(1.0, 0.0, 0.0 ))

	# Carregar a Textura para a Mem�ria de V�deo
	EarthTextureId = LoadTexture("textures/earth_2k.jpg");
	CloudsTextureId = LoadTexture("textures/earth_clouds_2k.jpg");

	# Configura a cor de fundo
	glClearColor(0.0, 0.0, 0.0, 1.0)

	# Identificador do Vertex Array Object (VAO)
	SphereVAO = GLuint()

	# Gerar o identificador do VAO
	glGenVertexArrays(1, &SphereVAO);

	# Habilitar o VAO
	glBindVertexArray(SphereVAO);

	# Habilita o atributo na posi��o 0, normalmente � o atributo de v�rtices
	# Esse vai ser o identificador que vamos usar no shader para ler a posi��o
	# de cada v�rtice, mas n�o se preocupe com isso agora. Vai ficar tudo mais
	# claro quando formos falar de shaders
	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	glEnableVertexAttribArray(2);
	glEnableVertexAttribArray(3);

	# Diz para o OpenGL que o VertexBuffer vai ficar associado ao atributo 0
	# glBindBuffer(GL_ARRAY_BUFFER, VertexBuffer);
	glBindBuffer(GL_ARRAY_BUFFER, SphereVertexBuffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, SphereElementBuffer);

	# Informa ao OpenGL onde, dentro do VertexBuffer, os v�rtices est�o. No
	# nosso caso o array Triangles � tudo o que a gente precisa
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), nullptr);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_TRUE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, Normal)));
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_TRUE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, Color)));
	glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, UV)));	

	# Disabilitar o VAO
	glBindVertexArray(0);

	PreviousTime = glfwGetTime();

	while(not glfwWindowShouldClose(Window)):
		CurrentTime = glfwGetTime()
		DeltaTime = CurrentTime - PreviousTime
		if (DeltaTime > 0.0):
			Camera.Update(static_cast<float>(DeltaTime))
			PreviousTime = CurrentTime

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

		glUseProgram(ProgramId);				
		
		ViewMatrix = Camera.GetView()
		NormalMatrix = glm.transpose(glm.inverse(ViewMatrix * ModelMatrix))
		ModelViewMatrix = ViewMatrix * ModelMatrix
		ModelViewProjectionMatrix = Camera.GetViewProjection() * ModelMatrix

		TimeLoc = glGetUniformLocation(ProgramId, "Time")
		glUniform1f(TimeLoc, CurrentTime)

		NormalMatrixLoc = glGetUniformLocation(ProgramId, "NormalMatrix")
		glUniformMatrix4fv(NormalMatrixLoc, 1, GL_FALSE, glm.value_ptr(NormalMatrix))

		ModelViewMatrixLoc = glGetUniformLocation(ProgramId, "ModelViewMatrix")
		glUniformMatrix4fv(ModelViewMatrixLoc, 1, GL_FALSE, glm.value_ptr(ModelViewMatrix))

		ModelViewProjectionLoc = glGetUniformLocation(ProgramId, "ModelViewProjection")
		glUniformMatrix4fv(ModelViewProjectionLoc, 1, GL_FALSE, glm.value_ptr(ModelViewProjectionMatrix))

		LightIntensityLoc = glGetUniformLocation(ProgramId, "LightIntensity")
		glUniform1f(LightIntensityLoc, Light.Intensity)

		LightDirectionViewSpace = ViewMatrix * glm.vec4( Light.Direction, 0.0)

		LightDirectionLoc = glGetUniformLocation(ProgramId, "LightDirection")
		glUniform3fv(LightDirectionLoc, 1, glm.value_ptr(LightDirectionViewSpace))

		glActiveTexture(GL_TEXTURE0)
		glBindTexture(GL_TEXTURE_2D, EarthTextureId)

		glActiveTexture(GL_TEXTURE1)
		glBindTexture(GL_TEXTURE_2D, CloudsTextureId)

		TextureSamplerLoc = glGetUniformLocation(ProgramId, "EarthTexture")
		glUniform1i(TextureSamplerLoc, 0)

		CloudsTextureSamplerLoc = glGetUniformLocation(ProgramId, "CloudsTexture")
		glUniform1i(CloudsTextureSamplerLoc, 1)

		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
		glBindVertexArray(SphereVAO)
		glDrawElements(GL_TRIANGLES, SphereIndices.size() * 3, GL_UNSIGNED_INT, nullptr)
		glBindVertexArray(0);

		glfwPollEvents();
		glfwSwapBuffers(Window)

	
	glDeleteBuffers(1, &SphereElementBuffer)
	glDeleteBuffers(1, &SphereVertexBuffer)
	glDeleteVertexArrays(1, &SphereVAO)
	glDeleteProgram(ProgramId);
	glDeleteTextures(1, &EarthTextureId)

	glfwDestroyWindow(Window)
	glfwTerminate()

}
